<?php 

    session_start();
        
    if(isset($_POST['logon']))
    {
        $_SESSION["login"] = $_POST['login'];
        $_SESSION["mdp"] = $_POST['password'];
    }
    else if (!$_SESSION)
    {
        $_SESSION["login"] = "guest";
        $_SESSION["mdp"] = "mdp";
    }
    
    if(isset($_POST['logout']))
    {
        unset($_SESSION['login']);
    }

    if(isset($_SESSION['login']))
        echo $_SESSION['login'];
    else
    {
        echo "session destroyed";
    }
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset='utf-8'>
		<title>Exercice 3</title> 
        <style>
            #onglets
                {
                    font : bold 11px Batang, arial, serif;
                    list-style-type : none;
                    padding-bottom : 24px; /* à modifier suivant la taille de la police ET de la hauteur de l'onglet dans #onglets li */
                    border-bottom : 1px solid #9EA0A1;
                    margin-left : 0;
                    width:20%;
                }
            #onglets li
                {
                    float : left;
                    height : 21px; /* à modifier suivant la taille de la police pour centrer le texte dans l'onglet */
                    background-color: #F4F9FD;
                    margin : 2px 2px 0 2px !important;  /* Pour les navigateurs autre que IE */
                    margin : 1px 2px 0 2px;  /* Pour IE  */
                    border : 1px solid #9EA0A1;
                }
            #onglets li.active
            {
                border-bottom: 1px solid #fff;
                background-color: #fff;
            }
            #onglets a
            {
                display : block;
                color : #666;
                text-decoration : none;
                padding : 4px;
            }
            #onglets a:hover
            {
                background : #fff;
            }

        </style>
	</head>
<body>
    
    <h1>Exercise 3</h1>

        <div id="menu">
            <ul id="onglets">
                <li class="active"><a href="login.php"> Login </a></li>
                <li><a href="welcome.php"> Page 1 </a></li>
                <?php 
                    if(isset($_SESSION['login']))
                    {
                        if($_SESSION['login'] == "Fred" && $_SESSION['mdp'] == "Bloggs")
                            echo "<li><a href='#'> Page 2 </a></li>";
                    }
                ?>
            </ul>
        </div>
</body>
</html>